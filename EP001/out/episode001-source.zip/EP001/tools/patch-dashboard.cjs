const fs=require('fs'),path=require('path');const {bundle}=require('@remotion/bundler');const {renderFrames,selectComposition,openBrowser,stitchFramesToVideo}=require('@remotion/renderer');const shots=require('../src/timeline.json');
const count=14789;const shotFor=f=>[...shots].reverse().find(s=>s.t<=f/30)||shots[0];
(async()=>{
 const serveUrl=await bundle({entryPoint:path.resolve('src/index.ts'),publicDir:path.resolve('public')});const browser=await openBrowser('chrome',{browserExecutable:'/usr/bin/chromium'});const results=[];
 for(const [id,prefix] of [['V1-Master','v1'],['EP001','final']]){
  const cache=JSON.parse(fs.readFileSync(`out/qa/${prefix}-frame-cache.json`));const selected=cache.selectedFrames.filter(f=>shotFor(f).view==='dashboard');const composition=await selectComposition({serveUrl,id,inputProps:{useMaster:false},puppeteerInstance:browser});let last=0;
  console.log('Patch',id,'dashboard frames',selected.length);
  const {assetsInfo}=await renderFrames({serveUrl,composition,inputProps:{useMaster:false},frames:selected,outputDir:path.resolve(`out/${prefix}-frames`),imageFormat:'jpeg',jpegQuality:92,concurrency:4,puppeteerInstance:browser,onFrameUpdate:n=>{if(n-last>=100){last=n;console.log(id,n,'/',selected.length);}}});
  const allSelected=new Set(cache.selectedFrames);const file=f=>path.resolve(`out/${prefix}-frames/element-${String(f).padStart(5,'0')}.jpeg`);let prior=0;
  for(let f=0;f<count;f++){if(allSelected.has(f))prior=f;else{fs.unlinkSync(file(f));fs.linkSync(file(prior),file(f));}}
  assetsInfo.firstFrameIndex=0;assetsInfo.chunkLengthInSeconds=count/30;assetsInfo.imageSequenceName=path.resolve(`out/${prefix}-frames/element-%05d.jpeg`);assetsInfo.assets=Array.from({length:count},(_,frame)=>({frame,audioAndVideoAssets:[],inlineAudioAssets:[],artifactAssets:[]}));results.push({id,prefix,assetsInfo,selected});
 }

 for(const {id,prefix,assetsInfo,selected} of results){const final=id==='EP001';const target=path.resolve(final?'out/episode001-review.mp4':'public/aroll.mp4');fs.copyFileSync(target,path.resolve(final?'out/episode001-review.pre-dashboard-fix.mp4':'out/aroll.pre-dashboard-fix.mp4'));
 await stitchFramesToVideo({assetsInfo,width:1920,height:1080,fps:30,codec:'h264',crf:18,x264Preset:'veryfast',muted:true,force:true,outputLocation:target,ffmpegOverride:final?({args,type})=>type!=='stitcher'?args:['-r','30','-f','image2','-s','1920x1080','-start_number','0','-i',assetsInfo.imageSequenceName,'-i',path.resolve('public/narration_final.wav'),'-map','0:v:0','-map','1:a:0','-c:v','libx264','-preset','veryfast','-crf','18','-pix_fmt','yuv420p','-c:a','aac','-ac','1','-ar','24000','-b:a','128k','-metadata','comment=Made with Remotion 4.0.539; original supplied narration','-y','-f','mp4',args[args.length-1]]:undefined});
 console.log('Corrected complete',id);fs.writeFileSync(`out/qa/${prefix}-dashboard-correction.json`,JSON.stringify({correctedFrames:selected.length,source:'Actual supplied app, dashboard scrolled 110px to reveal full stage labels/counts',totalOutputFrames:count},null,2));
 }
 await browser.close({silent:true});
})().catch(e=>{console.error(e);process.exit(1)});
