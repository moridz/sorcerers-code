// Remotion renders every changing frame. Only mathematically identical UI holds
// reuse image bytes; all 14789 native 30-fps output frames are then encoded by
// Remotion's stitchFramesToVideo. No motion frames or narration samples are cut.
const fs=require('fs'),path=require('path');
const {bundle}=require('@remotion/bundler');
const {renderFrames,stitchFramesToVideo,selectComposition,openBrowser}=require('@remotion/renderer');
const shots=require('../src/timeline.json');const chapters=require('../src/chapters.json');
const id=process.argv[2]||'V1-Master';const final=id==='EP001';
const smoke=process.argv.includes('--test');
const count=smoke?180:14789,fps=30;
const ruleStarts=[17.68,78.24,127.94,178.49,228.77,265.32,317.87,404.8,409.73,417.2,464.49,479.99];
const changes=[22.17,86.84,136.11,183.41,237.14,270.52,322.49,409.73,417.2,425.45,472.41,484.06,105.28,110.52,113.69,116.42,118.86,122.49,58.34,63.24,189.15,196,199.5,216.85,228.77,240.99,253.49,308.86,317.87,322.49,337.6,352.28,354.87,360.25,368.69,375.58,400.77,...chapters.map(c=>c.start)];
const frames=new Set([0,count-1]);
for(let i=0;i<shots.length;i++){
 const s=shots[i];const end=Math.min(count-1,Math.ceil((shots[i+1]?.t??493)*fps)-1);const start=Math.ceil(s.t*fps);
 for(let f=start;f<=Math.min(end,Math.ceil((s.t+3.5)*fps)+1);f++)frames.add(f);
 const hide=Math.floor((s.t+5)*fps)+1;if(hide<=end)frames.add(hide);
}
if(final){for(const s of ruleStarts){for(let f=Math.ceil(s*fps);f<=Math.ceil((s+.25)*fps)+1;f++)frames.add(f);}
for(const t of changes){const f=Math.ceil(t*fps);if(f<count)frames.add(f);}}
const selected=[...frames].filter(f=>f<count).sort((a,b)=>a-b);
(async()=>{
 const prefix=(final?'final':'v1')+(smoke?'-smoke':'');const dir=path.resolve(`out/${prefix}-frames`);fs.rmSync(dir,{recursive:true,force:true});fs.mkdirSync(dir,{recursive:true});
 const serveUrl=await bundle({entryPoint:path.resolve('src/index.ts'),publicDir:path.resolve('public')});
 const browser=await openBrowser('chrome',{browserExecutable:'/usr/bin/chromium'});
 const inputProps=final?{useMaster:!smoke}:{};
 const composition=await selectComposition({serveUrl,id,inputProps,puppeteerInstance:browser});
 if(smoke)composition.durationInFrames=count;
 console.log(new Date().toISOString(),id,'Native output frames:',count,'Unique changing/hold frames:',selected.length);
 let last=0;const start=Date.now();
 const result=await renderFrames({serveUrl,composition,inputProps,frames:selected,outputDir:dir,imageFormat:'jpeg',jpegQuality:92,concurrency:4,puppeteerInstance:browser,onFrameUpdate:(n)=>{if(n-last>=100){last=n;console.log('Rendered',n,'/',selected.length,'elapsed',Math.round((Date.now()-start)/1000),'s');}}});
 const info=result.assetsInfo;
 if(final && info.assets.some(f=>f.inlineAudioAssets.length)) throw new Error('Inline audio cannot be held; use source-backed continuous Html5Audio.');
 console.log('Rendered sequence',info.imageSequenceName,'assets',info.assets.length);
 const format=(f)=>info.imageSequenceName.replace(/%0(\d+)d/,(_,n)=>String(f).padStart(Number(n),'0'));
 let prior=0;for(let f=0;f<count;f++){if(frames.has(f))prior=f;else fs.linkSync(format(prior),format(f));}
 // A single continuous narration stream. Expand identical asset declarations over
 // held visual frames; mediaFrame follows native time, never the held image time.
 const assets=new Map(info.assets.map(a=>[a.frame,a]));let prev=assets.get(0)||{frame:0,audioAndVideoAssets:[],inlineAudioAssets:[],artifactAssets:[]};
 info.assets=Array.from({length:count},(_,f)=>{
  if(assets.has(f)){prev=assets.get(f);return prev;}
  return {...prev,frame:f,audioAndVideoAssets:prev.audioAndVideoAssets.map(a=>({...a,frame:f,mediaFrame:a.mediaFrame+(f-prev.frame)*a.playbackRate})),inlineAudioAssets:[],artifactAssets:[]};
 });
 info.chunkLengthInSeconds=count/fps;info.firstFrameIndex=0;
 fs.writeFileSync(`out/qa/${prefix}-frame-cache.json`,JSON.stringify({totalFrames:count,renderedFrames:selected.length,heldFrames:count-selected.length,selectedFrames:selected,rule:'Reuse only exact static UI holds; motion frames remain native 30 fps'},null,2));
 const target=path.resolve(smoke?'out/qa/cache-audio-test.mp4':final?'out/episode001-review.mp4':'public/aroll.mp4');
 if(!smoke&&fs.existsSync(target))fs.copyFileSync(target,path.resolve(final?'out/episode001-review.previous.mp4':'out/aroll.previous.mp4'));
 await stitchFramesToVideo({assetsInfo:info,width:1920,height:1080,fps,codec:'h264',crf:18,audioCodec:'aac',audioBitrate:'192k',outputLocation:path.resolve(smoke?'out/qa/cache-audio-test.mp4':final?'out/episode001-review.mp4':'public/aroll.mp4'),muted:true,force:true,x264Preset:final?'veryfast':'fast',ffmpegOverride:final?({args,type})=>type!=='stitcher'?args:['-r','30','-f','image2','-s','1920x1080','-start_number','0','-i',info.imageSequenceName,'-i',path.resolve('public/narration_final.wav'),'-map','0:v:0','-map','1:a:0','-c:v','libx264','-preset','veryfast','-crf','18','-pix_fmt','yuv420p','-c:a','aac','-ac','1','-ar','24000','-b:a','128k','-metadata','comment=Made with Remotion 4.0.539; original supplied narration','-y','-f','mp4',args[args.length-1]]:undefined,onProgress:p=>{if(p===1)console.log('Encoded complete');}});
 console.log(new Date().toISOString(),'COMPLETE',id);await browser.close({silent:true});
})().catch(e=>{console.error(e);process.exit(1)});
