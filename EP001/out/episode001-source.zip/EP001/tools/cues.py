import re,json
from pathlib import Path
r=Path(__file__).resolve().parents[1]
a=json.loads((r/'out/qa/forced-alignment.json').read_text())
words=[{**x,'word':re.sub(r'\(\d+\)$','',x['word'])} for x in a if not x['word'].startswith('<')]
def norm(s):return re.findall(r"[a-z']+",s.lower())
def find(s,after=0):
 q=norm(s)
 for i in range(len(words)-len(q)+1):
  if words[i]['start']>=after and [x['word'] for x in words[i:i+len(q)]]==q:return words[i]['start']
 raise ValueError(s)
chap=json.loads((r/'package/episode/TEST_INPUT.json').read_text())['chapters']
last=0; out=[]
for c in chap:
 t=find(' '.join(norm(c['text'])[:7]),last)
 out.append({'id':c['id'],'title':c['title'],'start':t});last=t+.1
print(json.dumps(out,indent=2));(r/'src/chapters.json').write_text(json.dumps(out,indent=2))
for c in chap:
 for sentence in re.split(r'(?<=[.!?])\s+',c['text']):
  try:print(f'{find(" ".join(norm(sentence)[:7])):7.2f}',sentence[:110])
  except:pass
(r/'out/qa/word-timestamps.json').write_text(json.dumps(words,indent=2))
