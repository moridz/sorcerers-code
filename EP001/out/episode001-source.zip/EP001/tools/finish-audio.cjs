// Audio finishing only: retain the completed Remotion picture stream and encode
// the original WAV directly as mono. This avoids the default mono→stereo gain
// conversion found by waveform QA. No time stretch, generated voice, or EQ.
const fs=require('fs'),path=require('path');const {bundle}=require('@remotion/bundler');const {renderFrames,selectComposition,stitchFramesToVideo}=require('@remotion/renderer');
(async()=>{
const target=path.resolve('out/episode001-review.mp4');const picture=path.resolve('out/episode001-review.pre-audio-fix.mp4');fs.copyFileSync(target,picture);
const serveUrl=await bundle({entryPoint:path.resolve('src/index.ts'),publicDir:path.resolve('public')});const composition=await selectComposition({serveUrl,id:'V1-Master',browserExecutable:'/usr/bin/chromium'});
const {assetsInfo}=await renderFrames({serveUrl,composition,frames:[0],outputDir:path.resolve('out/audio-finish-anchor'),imageFormat:'jpeg',browserExecutable:'/usr/bin/chromium',concurrency:1});
assetsInfo.imageSequenceName=path.resolve('out/final-frames/element-%05d.jpeg');assetsInfo.firstFrameIndex=0;assetsInfo.chunkLengthInSeconds=14789/30;
assetsInfo.assets=Array.from({length:14789},(_,frame)=>({frame,audioAndVideoAssets:[],inlineAudioAssets:[],artifactAssets:[]}));
const wav=path.resolve('public/narration_final.wav');
await stitchFramesToVideo({assetsInfo,width:1920,height:1080,fps:30,codec:'h264',muted:true,force:true,outputLocation:target,ffmpegOverride:({args,type})=>{
if(type!=='stitcher')return args;
return ['-i',picture,'-i',wav,'-map','0:v:0','-map','1:a:0','-c:v','copy','-c:a','aac','-ac','1','-ar','24000','-b:a','192k','-metadata','comment=Remotion EP001; original final WAV; no retiming','-y','-f','mp4',args[args.length-1]];
}});
console.log('Remotion audio finishing complete: original picture stream copied; exact source WAV encoded directly as mono.');
})().catch(e=>{console.error(e);process.exit(1)});
