from pathlib import Path
r=Path(__file__).resolve().parents[1]
s=(r/'package/demo/index.html').read_text()
addon='''<style>html,body{scroll-behavior:auto!important}body{overflow:hidden} .ep-focus{outline:3px solid #b78445!important;outline-offset:5px!important}#ep-cursor{position:fixed;z-index:100000;pointer-events:none;width:24px;height:30px;filter:drop-shadow(0 2px 2px #0003)}#ep-cursor svg{width:100%;height:100%}</style>
<div id="ep-cursor"><svg viewBox="0 0 24 30"><path d="M2 1 L21 19 L13 20 L10 28 L6 26 L9 18 L2 22Z" fill="white" stroke="#182339" stroke-width="1.5"/></svg></div>
<script>
const episodeOriginalStages=DATA.map(d=>d.stage);
let episodeStateKey=null,episodeFocus=null;
window.episodeSeek = (s) => {
 const key=JSON.stringify([s.owner,s.stage,s.moved]);
 if(key!==episodeStateKey){
 episodeStateKey=key;episodeFocus=null;
 DATA.forEach((d,i)=>d.stage=episodeOriginalStages[i]);
 if(s.moved) { const button=document.querySelector('[data-deal="D001"] .next'); if(button && DATA[0].stage==='Qualified') button.click(); DATA[0].stage='Proposal'; }
 for(const [id,val] of [['owner',s.owner||'all'],['stage',s.stage||'all']]) {const el=document.getElementById(id); el.value=val; el.dispatchEvent(new Event('change',{bubbles:true}));}
 render();
 }
 window.scrollTo(0,s.scroll||0);
 if(episodeFocus!==s.focus){episodeFocus=s.focus;
 document.querySelectorAll('.ep-focus').forEach(e=>e.classList.remove('ep-focus'));
 if(s.focus) document.querySelectorAll(s.focus).forEach(e=>e.classList.add('ep-focus'));
 }
 const cursor=document.getElementById('ep-cursor');cursor.style.left=s.cursor[0]+'px';cursor.style.top=s.cursor[1]+'px';cursor.style.opacity=s.cursor[2]??1;
 return {view,owner:document.getElementById('owner').value,stage:document.getElementById('stage').value,northwind:DATA[0].stage,records:rows().length,total:rows().reduce((sum,d)=>sum+Number(d.value_usd),0)};
};
</script>'''
(r/'public/demo.html').write_text(s.replace('</body>',addon+'</body>'))
(r/'public/narration_final.wav').write_bytes((r/'package/assets/audio/narration_final.wav').read_bytes())
