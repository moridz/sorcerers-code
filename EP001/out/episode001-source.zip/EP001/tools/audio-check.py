from pathlib import Path
import wave,math,hashlib,json,re,difflib,array,statistics
r=Path(__file__).resolve().parents[1]
p=r/'public/narration_final.wav';w=wave.open(str(p)); samples=array.array('h',w.readframes(w.getnframes()));peak=max(abs(x) for x in samples)
words=json.loads((r/'out/qa/word-timestamps.json').read_text());asr=json.loads((r/'out/qa/independent-asr.json').read_text())
def norm(s):return re.findall(r"[a-z']+",s.lower())
reference=norm(' '.join(x['text'] for x in json.loads((r/'package/episode/TEST_INPUT.json').read_text())['chapters']))
hyp=norm((r/'out/qa/independent-asr.txt').read_text())
# Exact phrase matches in independent (unprompted) ASR support cue positions.
a=[x for x in asr if not x['word'].startswith('<')];lookup={}
for i in range(len(a)-3):lookup.setdefault(tuple(re.sub(r'\(\d+\)$','',v['word']) for v in a[i:i+4]),[]).append(a[i]['start'])
matches=[]
for i in range(len(words)-3):
 key=tuple(v['word'] for v in words[i:i+4]); candidates=lookup.get(key,[])
 if candidates:
  t=min(candidates,key=lambda t:abs(t-words[i]['start']))
  if abs(t-words[i]['start'])<1:matches.append({'phrase':' '.join(key),'forced_start':words[i]['start'],'asr_start':t,'offset':round(t-words[i]['start'],3)})
report={'source_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'source_matches_package':p.read_bytes()==(r/'package/assets/audio/narration_final.wav').read_bytes(),'duration_seconds':len(samples)/w.getframerate(),'sample_rate':w.getframerate(),'channels':w.getnchannels(),'peak_dbfs':20*math.log10(peak/32768),'clipped_samples':sum(abs(x)>=32767 for x in samples),'alignment':'PocketSphinx 5.0.4 acoustic forced alignment, cmudict plus Northwind/CRM pronunciations; no speech retiming','independent_asr':'PocketSphinx default English LM; imperfect transcription, not a verbatim certification','matching_four_word_cues':len(matches),'median_absolute_cue_offset':statistics.median(abs(x['offset']) for x in matches),'checks':matches}
(r/'out/qa/audio-analysis.json').write_text(json.dumps(report,indent=2));print({k:v for k,v in report.items() if k!='checks'})
