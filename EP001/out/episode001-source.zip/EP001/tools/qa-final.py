import json,subprocess,wave,array,math,hashlib
from pathlib import Path
r=Path(__file__).resolve().parents[1];out=r/'out';qa=out/'qa';movie=out/'episode001-review.mp4'
def run(args):return subprocess.run(args,check=True,capture_output=True,text=True)
meta=json.loads(run(['ffprobe','-v','error','-show_format','-show_streams','-of','json',str(movie)]).stdout);(qa/'final-ffprobe.json').write_text(json.dumps(meta,indent=2))
subprocess.run(['ffmpeg','-v','error','-i',str(movie),'-f','null','-'],check=True,stderr=(qa/'full-decode.log').open('w'))
subprocess.run(['ffmpeg','-v','error','-y','-i',str(movie),'-vn','-ar','24000','-ac','1','-f','s16le',str(qa/'final-audio.pcm')],check=True)
w=wave.open(str(r/'public/narration_final.wav'));a=array.array('h',w.readframes(w.getnframes()));b=array.array('h',(qa/'final-audio.pcm').read_bytes());n=min(len(a),len(b));step=8
av=a[:n:step];bv=b[:n:step];ab=sum(x*y for x,y in zip(av,bv));aa=sum(x*x for x in av);bb=sum(y*y for y in bv);corr=ab/math.sqrt(aa*bb);snr=10*math.log10(aa/max(1,sum((x-y)**2 for x,y in zip(av,bv))))
video=[s for s in meta['streams'] if s['codec_type']=='video'];audio=[s for s in meta['streams'] if s['codec_type']=='audio'];v=video[0]
report={'file':str(movie.relative_to(r)),'sha256':hashlib.sha256(movie.read_bytes()).hexdigest(),'video_streams':len(video),'audio_streams':len(audio),'width':v['width'],'height':v['height'],'fps':v['avg_frame_rate'],'video_codec':v['codec_name'],'audio_codec':audio[0]['codec_name'],'duration':meta['format']['duration'],'audio_channels':audio[0]['channels'],'audio_sample_rate':audio[0]['sample_rate'],'sampled_linear_gain':ab/aa,'source_seconds':len(a)/24000,'decoded_audio_seconds':len(b)/24000,'zero_lag_source_audio_correlation':corr,'codec_roundtrip_snr_db_sampled':snr,'source_wav_unchanged':hashlib.sha256((r/'public/narration_final.wav').read_bytes()).hexdigest()=='74c7964acc06917370cc0176de06af176189626a59628af11a282a49486fd533','full_decode':'PASS'}
assert report['source_wav_unchanged'] and len(video)==len(audio)==1 and v['width']==1920 and v['height']==1080 and v['avg_frame_rate']=='30/1'
assert corr>.99 and .98<ab/aa<1.02 and snr>25 and abs(float(meta['format']['duration'])-492.95)<.15
(qa/'technical-results.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
