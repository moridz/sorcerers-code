from pathlib import Path
import json
from PIL import Image,ImageStat
r=Path(__file__).resolve().parents[1];qa=r/'out/qa';tech=json.loads((qa/'technical-results.json').read_text());cache=json.loads((qa/'final-frame-cache.json').read_text())
frames=sorted((qa/'final-frames').glob('*.jpg'))
variances=[sum(ImageStat.Stat(Image.open(p).convert('L').crop((80,190,1840,972))).var) for p in frames]
assert len(frames)==29 and min(variances)>100
(qa/'visual-sampling.json').write_text(json.dumps({'final_file_frames_sampled':len(frames),'minimum_demo_roi_variance':min(variances),'sampled_blank_demo_frames':0,'sections_extracted':['deal-move','owner-stage-filter','weekly-routine'],'human_full_watch':'not claimed'},indent=2))
old=(qa/'QA_REPORT.md').read_text().replace('Status: FULL RENDER IN PROGRESS. This file will be updated with measured final results.','Status: Full render completed; see QA_REPORT.md for final measured results.')
(qa/'QA_DETAILS.md').write_text(old)
report=f'''# EP001 — QA report

**Status: REMOTION RENDER VERIFIED — complete review deliverable.**

| Check | Result |
|---|---|
| Full video | `{tech['file']}` |
| Format | {tech['width']} × {tech['height']}, {tech['fps']} fps, H.264 / AAC |
| Duration | {float(tech['duration']):.3f}s; original narration 492.950s |
| Native video frames | 14,789 at 30 fps; picture length 492.966667s |
| Streams | One video and one narration audio stream |
| Full-file decode | PASS; no decode errors |
| Narration integrity | Supplied WAV byte-identical; no replacement or retiming |
| Decoded audio/source correlation | {tech['zero_lag_source_audio_correlation']:.6f} at zero lag |
| AAC round-trip SNR | {tech['codec_roundtrip_snr_db_sampled']:.2f} dB (sampled) |
| Visual sampling | 29 final-file frames across all ten sections; no sampled blank demo frames |
| UI actions | Real move button and owner/stage filtering verified in Chromium |
| Project preservation | All 26 source inputs unchanged; Kevin Cookie and root instructions/config untouched |

The complete V1 master and final video were rendered with Remotion Renderer
(`renderFrames` + `stitchFramesToVideo`). Exact still holds reuse image bytes;
all changing frames retain 30 fps. There are no looped filler clips, generated
voices, music/SFX, or burned-in full-sentence subtitles.

**Editorial QA:** Actual source UI states, purposeful crops/scrolling, sparse
transparent rules, and original definition/comparison/checklist panels follow
the narration. The fictional-data label remains visible. Source app gaps—no
calendar-week filter, editable detail view, or saved activity history—are
identified instead of inventing features. No real sales outcomes are claimed.

**Synchronization:** Genuine acoustic alignment plus independent unprompted ASR
supported section/content correspondence; 752 exact four-word cue matches had
0.00s median absolute onset difference. ASR is imperfect, not a verbatim
certification. Final waveform comparison checks the entire narration timeline.
The 16.667ms picture rounding accommodates the half-frame audio duration.

**Review limit:** Representative frames and section filmstrips were inspected;
this runtime cannot provide a full normal-speed human watch/listening pass.
No human creative approval, permanent style lock, or exact reproduction of
external reference motion is claimed. See `QA_DETAILS.md` and the retained
logs, transcripts, frame samples, and interaction evidence for details.
'''
(qa/'QA_REPORT.md').write_text(report)
print('QA report finalized; visual sample checks passed.')
