from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import subprocess,json
r=Path(__file__).resolve().parents[1];qa=r/'out/qa';frames=qa/'final-frames';frames.mkdir(exist_ok=True)
times=[0,13,38,60,75,90,120,146,185,190,198,220,242,267,289,293,310,325,343,358,363,370,378,393,411,420,451,460,491]
expr='+'.join(f'eq(n,{t*30})' for t in times)
subprocess.run(['ffmpeg','-v','error','-y','-i',str(r/'out/episode001-review.mp4'),'-vf',f"select='{expr}'",'-fps_mode','vfr','-q:v','2',str(frames/'%03d.jpg')],check=True)
fs=sorted(frames.glob('*.jpg'));assert len(fs)==len(times),(len(fs),len(times))
im=Image.new('RGB',(1920,1200),'#101827');d=ImageDraw.Draw(im)
for i,(p,t) in enumerate(zip(fs,times)):
 x=i%5*384;y=i//5*200;pic=Image.open(p);pic.thumbnail((380,175));im.paste(pic,(x,y));d.text((x+6,y+176),f'{t//60:02}:{t%60:02}',fill='white')
im.save(qa/'FINAL_CONTACT_SHEET.jpg');(qa/'final-frame-times.json').write_text(json.dumps(dict(zip([p.name for p in fs],times)),indent=2))
for start,duration,name in [(183,12,'deal-move'),(287,11,'owner-stage-filter'),(352,29,'weekly-routine')]:
 subprocess.run(['ffmpeg','-v','error','-y','-ss',str(start),'-i',str(r/'out/episode001-review.mp4'),'-t',str(duration),'-c:v','libx264','-preset','veryfast','-crf','22','-c:a','aac','-b:a','128k',str(qa/(name+'.mp4'))],check=True)
print('Extracted final-file inspection frames and three native video/audio sections.')
