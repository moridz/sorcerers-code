from pocketsphinx import Decoder
from pathlib import Path
import wave,json
r=Path(__file__).resolve().parents[1]
d=Decoder(samprate=16000)
w=wave.open(str(r/'out/qa/alignment.wav'));d.start_utt()
while True:
 b=w.readframes(16000*10)
 if not b: break
 d.process_raw(b,False,False)
d.end_utt()
(r/'out/qa/independent-asr.txt').write_text(d.hyp().hypstr)
(r/'out/qa/independent-asr.json').write_text(json.dumps([{'word':s.word,'start':s.start_frame/100,'end':s.end_frame/100} for s in d.seg()],indent=2))
print('ASR complete')
