import json,subprocess,re,wave,time
from pathlib import Path
from pocketsphinx import Decoder
root=Path(__file__).resolve().parents[1]
subprocess.run(['ffmpeg','-v','error','-y','-i',str(root/'package/assets/audio/narration_final.wav'),'-ar','16000','-ac','1',str(root/'out/qa/alignment.wav')],check=True)
chapters=json.loads((root/'package/episode/TEST_INPUT.json').read_text())['chapters']
text=' '.join(c['text'] for c in chapters)
text=re.sub('[^a-z\s\']',' ',text.lower())
w=wave.open(str(root/'out/qa/alignment.wav')); data=w.readframes(w.getnframes())
d=Decoder(samprate=16000)
extra={'northwind':'N AO R TH W IH N D','crm':'S IY AA R EH M'}
for word in set(text.split()):
 if not d.lookup_word(word):
  if word not in extra: raise ValueError('Unknown pronunciation '+word)
  d.add_word(word,extra[word],False)
d.set_align_text(text);d.start_utt();d.process_raw(data,False,True);d.end_utt()
segments=[dict(word=s.word,start=s.start_frame/100,end=(s.end_frame+1)/100) for s in d.seg()]
(root/'out/qa/forced-alignment.json').write_text(json.dumps(segments,indent=2))
print('Aligned',len(segments),'segments',flush=True)
