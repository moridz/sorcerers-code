import React from 'react';
import {Composition,registerRoot,staticFile} from 'remotion';
import {Video} from '@remotion/media';
const Clip=()=> <Video src={staticFile('qa-decoder.mp4')} muted style={{width:'100%',height:'100%'}}/>;
const Root=()=> <Composition id="VideoTest" component={Clip} durationInFrames={60} fps={30} width={1920} height={1080}/>;
registerRoot(Root);
