#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
python3 tools/build-demo.py
npm run typecheck
npx remotion render src/index.ts V1-Master public/aroll.mp4 --browser-executable=/usr/bin/chromium --concurrency=4 --codec=h264 --crf=18 > out/qa/aroll-render.log 2>&1
npm run render > out/qa/final-render.log 2>&1
