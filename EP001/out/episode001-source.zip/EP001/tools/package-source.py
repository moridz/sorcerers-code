from pathlib import Path
import zipfile
r=Path(__file__).resolve().parents[1]
with zipfile.ZipFile(r/'out/episode001-source.zip','w',zipfile.ZIP_DEFLATED) as z:
 for folder in ['src','tools','package']:
  for p in (r/folder).rglob('*'):
   if p.is_file():z.write(p,Path('EP001')/p.relative_to(r))
 for name in ['README.md','package.json','package-lock.json','tsconfig.json','.gitignore','asset_manifest.json','editorial-decisions.json','public/demo.html']:
  p=r/name
  if p.exists():z.write(p,Path('EP001')/name)
 for name in ['QA_REPORT.md','QA_DETAILS.md','TOOL_LOG.md','preservation.json','aroll-ffprobe.json','audio-finishing.log','corrected-encoding.log','v1-dashboard-correction.json','final-dashboard-correction.json','technical-results.json','audio-analysis.json','cache-audio-test-results.json','ui-interactions.json','source-ffprobe.txt','word-timestamps.json','cues.txt','independent-asr.txt','independent-asr.json','final-frame-cache.json','v1-frame-cache.json','FINAL_CONTACT_SHEET.jpg','final-ffprobe.json','aroll-render.log','final-render.log']:
  p=r/'out/qa'/name
  if p.exists():z.write(p,Path('EP001/out/qa')/name)
print('Source archive:',(r/'out/episode001-source.zip').stat().st_size,'bytes')
