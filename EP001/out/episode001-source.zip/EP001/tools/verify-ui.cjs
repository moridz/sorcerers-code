const puppeteer=require('puppeteer-core');const fs=require('fs');
(async()=>{const b=await puppeteer.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox']});const p=await b.newPage();await p.setViewport({width:1530,height:680});const out=[];
await p.goto('http://localhost:8001/demo.html?view=board');
const before=await p.$eval('[data-deal="D001"]',e=>e.closest('.lane').dataset.stage);await p.click('[data-deal="D001"] .next');const after=await p.$eval('[data-deal="D001"]',e=>e.closest('.lane').dataset.stage);out.push({action:'Click Move to Proposal',before,after});
await p.screenshot({path:'out/qa/actual-click-result.png'});
await p.goto('http://localhost:8001/demo.html?view=dashboard');
for(const [owner,stage] of [['all','all'],['Sara','all'],['Sara','Proposal']]){await p.select('#owner',owner);await p.select('#stage',stage);out.push({owner,stage,kpis:await p.$$eval('.kpi',es=>es.map(e=>e.textContent))});}
await p.screenshot({path:'out/qa/actual-filter-result.png'});fs.writeFileSync('out/qa/ui-interactions.json',JSON.stringify(out,null,2));console.log(out);await b.close();})();
