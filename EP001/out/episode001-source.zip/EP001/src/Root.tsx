import React,{useLayoutEffect,useRef} from 'react';
import {AbsoluteFill,Composition,continueRender,delayRender,interpolate,staticFile,useCurrentFrame,useVideoConfig} from 'remotion';
import {Video} from '@remotion/media';
import {Html5Audio as Audio} from 'remotion';
import shots from './timeline.json';
import chapters from './chapters.json';
const ink='#182339',accent='#98703d',muted='#697585';
const clamp={extrapolateLeft:'clamp',extrapolateRight:'clamp'} as const;
const Demo=()=>{
 const frame=useCurrentFrame();const {fps}=useVideoConfig();const time=frame/fps;
 const shot=[...shots].reverse().find(s=>s.t<=time)||shots[0];
 const iframe=useRef<HTMLIFrameElement>(null);const pending=useRef<(()=>void)|null>(null);
 useLayoutEffect(()=>{
  const handle=delayRender('Await actual Pipeline Lab UI frame');let cancelled=false,done=false;
  const finish=()=>{if(!done){done=true;continueRender(handle);}};
  const apply=()=>{
   if(cancelled)return;
   const w=iframe.current?.contentWindow as (Window&{episodeSeek?:(s:unknown)=>unknown})|null;
   if(!w?.episodeSeek)return;
   let p=Math.min(1,Math.max(0,(time-shot.t)/3.5));p=p*p*(3-2*p);
   const cursor=[shot.cursor[0]+(shot.to[0]-shot.cursor[0])*p,shot.cursor[1]+(shot.to[1]-shot.cursor[1])*p,time-shot.t>5?0:1];
   w.episodeSeek({...shot,cursor,scroll:('scroll' in shot?Number(shot.scroll)*(shot.view==='dashboard'?1:p):0)});
   // episodeSeek is synchronous; force layout before releasing the frame.
   w.document.body.getBoundingClientRect();finish();
  };pending.current=apply;apply();return()=>{cancelled=true;finish();};
 },[frame,fps,shot,time]);
 const camera=1+((('zoom' in shot?Number(shot.zoom):1)-1)*Math.min(1,(time-shot.t)/.7));
 return <div style={{width:1760,height:782,transformOrigin:'origin' in shot?String(shot.origin):'50% 50%',scale:camera}}><iframe ref={iframe} key={shot.view} title="Actual supplied Pipeline Lab app" src={`${staticFile('demo.html')}?view=${shot.view}`} onLoad={()=>pending.current?.()} style={{width:1530,height:680,border:0,transformOrigin:'top left',scale:'1.15',background:'#eff2f8'}}/></div>;
};
const V1=()=> <AbsoluteFill style={{background:'#edf0f2'}}><div style={{position:'absolute',left:80,top:190,width:1760,height:782,overflow:'hidden',border:'1px solid #d5dbe3',borderRadius:14,boxShadow:'0 10px 30px #18233910'}}><Demo/></div></AbsoluteFill>;
const Info:React.FC<{eyebrow:string;title:string;children:React.ReactNode;left?:boolean}>=({eyebrow,title,children,left})=><div style={{position:'absolute',right:left?undefined:105,left:left?105:undefined,top:386,width:620,padding:36,background:'#fbfcfd',border:'1px solid #d4dce5',borderLeft:`5px solid ${accent}`,borderRadius:12,boxShadow:'0 14px 44px #18233922',fontFamily:'Arial, sans-serif',color:ink}}><div style={{fontSize:16,fontWeight:700,letterSpacing:2,color:accent,marginBottom:14}}>{eyebrow}</div><div style={{fontSize:36,fontWeight:700,letterSpacing:-.8,lineHeight:1.2,marginBottom:22}}>{title}</div>{children}</div>;
const Line:React.FC<{label:string;body:string}>=({label,body})=><div style={{padding:'14px 0',borderTop:'1px solid #e2e6eb',fontSize:23,lineHeight:1.35}}><strong>{label}</strong><div style={{fontSize:21,color:muted,marginTop:5}}>{body}</div></div>;
const V2=()=>{
 const f=useCurrentFrame();const {fps}=useVideoConfig();const t=f/fps;
 const chapter=[...chapters].reverse().find(c=>c.start<=t)||chapters[0];
 const rules=[
 {a:17.68,b:22.17,text:'A clear workflow beats a prettier spreadsheet.'},
 {a:78.24,b:86.84,text:'Keep only the fields that support a decision.'},
 {a:127.94,b:136.11,text:'One stage. One shared meaning.'},
 {a:178.49,b:183.41,text:'Move the deal when the evidence changes.'},
 {a:228.77,b:237.14,text:'ACTION  +  OWNER  +  DUE DATE'},
 {a:265.32,b:270.52,text:'Potential value ≠ earned revenue'},
 {a:317.87,b:322.49,text:'The board points to questions. It does not prove causes.'},
 {a:404.8,b:409.73,text:'01  A stage label is not evidence.'},
 {a:409.73,b:417.2,text:'02  Pipeline value is not money received.'},
 {a:417.2,b:425.45,text:'03  Current totals need current records.'},
 {a:464.49,b:472.41,text:'Start with the decision. Then choose the fields.'},
 {a:479.99,b:484.06,text:'Clear operating rules come first.'}];
 const rule=rules.find(r=>t>=r.a&&t<r.b);
 return <AbsoluteFill style={{fontFamily:'Arial, sans-serif',color:ink,pointerEvents:'none'}}>
 <div style={{position:'absolute',left:82,top:53,color:accent,fontSize:17,fontWeight:700,letterSpacing:3}}>PIPELINE FIELD GUIDE <span style={{color:'#a4acb6',margin:'0 18px'}}>/</span> EP001</div>
 <div style={{position:'absolute',left:80,top:88,fontSize:48,fontWeight:700,letterSpacing:-1.6}}>{chapter.title}</div>
 <div style={{position:'absolute',right:83,top:77,textAlign:'right',fontSize:17,color:muted}}>FICTIONAL WORKFLOW DEMONSTRATION<div style={{marginTop:13,fontSize:28,color:ink}}>{chapter.id} <span style={{color:'#a5acb5'}}>/ 10</span></div></div>
 <div style={{position:'absolute',left:82,top:150,width:1756,height:2,background:'#d6dce3'}}/>
 {rule?<div style={{position:'absolute',left:82,top:1000,fontSize:28,fontWeight:600,opacity:interpolate(f,[rule.a*fps,(rule.a+.25)*fps],[0,1],clamp)}}>{rule.text}</div>:<div style={{position:'absolute',left:82,top:1007,fontSize:18,color:muted}}>Original supplied demo · Fictional accounts and amounts · No commercial CRM endorsement</div>}
 </AbsoluteFill>;
};
const V3=()=>{
 const frame=useCurrentFrame();const {fps}=useVideoConfig();const t=frame/fps;
 if(t>=105.28&&t<122.49)return <Info eyebrow="STAGE DEFINITIONS · ILLUSTRATIVE" title="A shared meaning for each column">{t>=110.52&&<Line label="New" body="Arrived, not yet assessed"/>}{t>=113.69&&<Line label="Qualified" body="Confirmed worth pursuing"/>}{t>=116.42&&<Line label="Proposal" body="Offer presented"/>}{t>=118.86&&<Line label="Decision" body="Buyer considering the next step"/>}</Info>;
 if(t>=58.34&&t<63.24)return <Info eyebrow="SOURCE CHECK" title="What is actually in the raw view"><Line label="Account · Owner · Value · Status · Action" body="Due days are in the dataset and board cards; this raw table does not display a date column."/></Info>;
 if(t>=189.15&&t<199.5)return <Info left eyebrow="ACTUAL DEMO ACTION" title="Northwind Cafe → Proposal"><Line label="Qualified → Proposal" body="Moved with the app’s existing button. The example assumes a proposal has been sent."/>{t>=196&&<Line label="History is a workflow recommendation" body="This demo does not implement a saved activity log."/>}</Info>;
 if(t>=216.85&&t<228.77)return <Info left eyebrow="EXPLANATORY EXAMPLE · NOT SAVED RECORDS" title="Same stage, different work"><Line label="Proposal A" body="Clarify pricing today"/><Line label="Proposal B" body="Check in next week"/></Info>;
 if(t>=240.99&&t<253.49)return <Info eyebrow="DEMO CAPABILITY NOTE" title="Due actions, ordered by day"><Line label="Available: due-action list + owner filter" body="This app has no “due this week” toggle or calendar dates. The list uses fictional due-day numbers."/></Info>;
 if(t>=308.86&&t<317.87)return <Info left eyebrow="HYPOTHESIS, NOT A MEASURED RESULT" title="A queue is a prompt to investigate"><Line label="Many proposals, few decisions?" body="Possible causes: waiting on the buyer or a missing follow-up. Sample counts alone cannot identify a cause."/></Info>;
 if(t>=322.49&&t<337.6)return <Info eyebrow="SOURCE RECORD · ARBOR CREATIVE" title="Inspect the underlying record"><Line label="Sara · Proposal · $3,000" body="Source dataset: due day 14; last contact day 1."/><Line label="Send revised quotation" body="Values are fictional day numbers. This demo has no record-detail editor or overdue-date clock."/></Info>;
 if(t>=337.6&&t<352.28)return <Info eyebrow="CLARIFICATION EXAMPLE · NOT AN APP EDIT" title="Make the instruction executable"><Line label="Before" body="Follow up soon"/><Line label="After" body="Send revised quotation — Sara — Thursday"/></Info>;
 if(t>=352.28&&t<400.77){const cues=[354.87,360.25,368.69,375.58];const labels=['Review due actions','Inspect stalled proposals','Fix missing owners or dates','Review totals last'];const selected=cues.filter(c=>t>=c).length-1;return <Info eyebrow="WEEKLY OPERATING ROUTINE" title="Keep the records useful">{labels.map((label,i)=><div key={label} style={{padding:'17px 0',borderTop:'1px solid #dde3ea',color:i===selected?ink:'#929aa6',fontSize:24,fontWeight:i===selected?700:400,display:'flex',gap:20}}><span style={{color:i<=selected?accent:'#abb2bc'}}>{i<selected?'✓':String(i+1).padStart(2,'0')}</span>{label}</div>)}<div style={{fontSize:18,color:muted,marginTop:18}}>Procedure recommendation; no missing records or stalled outcomes are claimed.</div></Info>;}
 return null;
};
const Episode=({useMaster=false}:{useMaster?:boolean})=>{const {fps}=useVideoConfig();return <AbsoluteFill>{useMaster?<Video src={staticFile('aroll.mp4')} muted premountFor={fps} style={{width:'100%',height:'100%'}}/>:<V1/>}<Audio src={staticFile('narration_final.wav')}/><V2/><V3/></AbsoluteFill>;};
export const Root=()=> <><Composition id="EP001" component={Episode} defaultProps={{useMaster:false}} durationInFrames={14789} fps={30} width={1920} height={1080}/><Composition id="V1-Master" component={V1} durationInFrames={14789} fps={30} width={1920} height={1080}/></>;
