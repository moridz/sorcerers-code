# EP001 — Autonomous Codex edit test

**Goal:** Give Codex your materials and let it edit a genuinely polished **8:12.95** video independently. Not a niche-validation task.

**What is provided:** final narration WAV, 1,474-word script, genuine interactive fictional sales dashboard, eight browser screenshots, fictional CSV, asset dictionary, optional storyboard, permanent `AGENTS.md` master, and a brief editing task.

**What is deliberately NOT provided:** a prescribed sequence of shots, exact B-roll timings, transition inventory, mandatory text animation count, or hardcoded frame-by-frame storyboard. These decisions belong to Codex.

**Status:** Assets packaged and audio metadata fixed; Codex has **not** yet performed the edit or Remotion render.

## Browser-only handoff

Use the GitHub + Codex Cloud procedure in `CLOUD_HANDOFF.md`. The packaged ZIP can be uploaded as one file to a separate private repository; Codex should unpack it first using the opening instructions in `START_WITH_CODEX.txt`.
