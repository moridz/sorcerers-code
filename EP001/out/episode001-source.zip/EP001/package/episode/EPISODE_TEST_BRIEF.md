# EP001 — AUTONOMOUS CODEX EDITING TEST (TEMPORARY EXCEPTION)

## Purpose

Determine whether Codex Cloud can autonomously create a **polished 8–12-minute faceless explainer**, working from a finished voice recording, content/script, genuine visual source assets, and one style master. **No viral-video or demand validation in this test.** Permanent master rules remain unchanged.

## Supplied source material

- `AGENTS.md`: the user's existing master v2.1. Read in full; respect core visual, factual, audio and four-track constraints.
- `assets/audio/narration_final.wav`: actual user-supplied 8:12.95 final test narration; preserve exactly; do not generate a replacement, speed-adjust or layer duplicate audio. The filename references Onyx/GPT-4o-mini TTS; its service provenance is not verified.
- `episode/SCRIPT_APPROVED_FOR_TEST.md` and `episode/CARTESIA_NARRATION_PLAIN_TEXT.txt`: the prepared, fictional scenario narration text, **reference for synchronization, not authority to replace what is actually spoken**.
- `demo/index.html`: a working, custom HTML interface populated with 30 **fictional** sales opportunities; usable for genuine screen recording or direct code inspection.
- `assets/screenshots/`, `assets/data/fictional_sales_pipeline.csv`, `assets/ASSET_INDEX.json`: source visual states, fictional data, index.
- `episode/STORYBOARD_INTENT.md`: **optional creative context, not a shot list**. Codex may replace its suggestions when that improves accuracy, readability and audience understanding.

## What Codex owns

You are the **editor and creative director**, not a mechanical compositor. Inspect the script, audio, interactive demo, screenshots, and selected visual references in `AGENTS.md`. **Make all reasonable editorial decisions autonomously**: coverage, shot choice, footage capture, pacing, meaningful motion/reframing, B-roll selection/creation, transparent text placement, transitions (if needed), full-episode rhythm and quality corrections. You may create original supporting assets where needed and lawful. Prioritize a watchable, well-explained video over filling a time budget with irrelevant visuals. No imposed count of cuts, text overlays, B-roll items, camera moves, or animation effects.

Preserve the project's durable constraints: continuous V1 primary presentation + narration, V2 text/visual overlays where useful, V3 substantive inserts, optional music (default OFF); no cartoon spokesperson, no imitation of actual paid CRM software, no fabricated outcomes, no decorative editing for its own sake. The uploaded reference URLs are *style inspiration*, not copyrighted source materials to be reproduced.

Use **Remotion** for the final composition and render. Determine whether to build the V1 master using authentic recorded UI actions, preassembled original footage, or another coherent informative solution. Do not merely loop one screenshot while narration plays. Verify narration/script correspondence using genuine transcription/alignment; detect and report any material mismatch, but do not silently alter supplied audio.

## Output

- Produce and **render the complete video** as `out/episode001-review.mp4` with original Remotion project source and reproducible command. Target 1920×1080 30 fps, video duration driven by the supplied 492.95s WAV.
- During your own QA, render any short samples/stills you consider necessary; examine real frames and listen to actual audio. **Do not stop and await human approval after a 20–30-second sample.** The user will review the full video when ready.
- Keep logs showing the actual tools invoked; supply a concise asset/shot-decision summary and `out/qa/QA_REPORT.md` with factual technical results and remaining defects. Preserve the last good output when revising.
- If an unavoidable access, rights, source, or execution blocker prevents truthful delivery, report the concrete blocker with attempted commands; never substitute an FFmpeg-only render while claiming it was Remotion.

## Acceptance

The evaluation is the **finished video** and the editing decisions it reveals, not how many effects were created. An MP4 that merely decodes is not evidence of professional quality.
