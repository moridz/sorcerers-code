# Storyboard intent — Codex chooses actual editing beats and times

This is an **editorial guide, not a mandatory shot-by-shot timeline**. After examining the real demo, Codex should choose informative cuts itself. Every shot must have a purpose.

| Script section | Main visual to demonstrate on V1 | Contextual V2 / V3 candidates | Editing intention |
|---|---|---|---|
| 01 Problem | Browser opens intro then raw spreadsheet | Short transparent title if needed | Establish the problem with real records |
| 02 Raw sheet | Scroll `?view=sheet` to show inconsistent statuses | Tight crop of source-status/action columns | Evidence of ambiguity |
| 03 Define stages | Browser shows stage labels; move to board | Four-step stage label near board, not on top of text | Make definitions visible |
| 04 Build board | Click Move to Proposal on a Qualified deal in the interactive app | Close-up of the moved card only | Demonstrate a meaningful action |
| 05 Next actions | Open `?view=actions`, show before/after cards | Transparent `ACTION + OWNER + DUE DATE` | Explain the actionable field |
| 06 Dashboard | `?view=dashboard`; change owner dropdown | Brief metric label/caveat only | Demonstrate linked data filtering |
| 07 Bottleneck | Compare a stalled Proposal card vs clarified next action | Simple two-up comparison | Prove how next action changes work |
| 08 Weekly routine | `?view=routine` four-step checklist | Highlight one step at a time, do not make full-screen filler | Present reusable procedure |
| 09 Mistakes | Actual sheet vs board vs dashboard states | Three precise warning labels where spoken | Show failure modes without fake effects |
| 10 Recap | Board/dashboard restored | Optional final one-line key takeaway | Finish on usable result |

**No generic stock B-roll required.** Real interface states and selectively cropped originals are better for this topic. The demo is fictional and must remain clearly described as such.
