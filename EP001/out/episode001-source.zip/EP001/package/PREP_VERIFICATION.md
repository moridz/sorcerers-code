# Preparation verification — editorial-autonomy handoff

- The user-supplied original WAV is copied byte-for-byte and SHA-256 checked.
- Actual audio duration: **492.950 seconds** (8:12.95), 24,000 Hz, mono, 16-bit PCM.
- **Corrected error in previous handoff:** the file's metadata incorrectly stated 89,478 seconds and 2,684,355 frames. Those values were not obtained from the real WAV. Correct duration at 30 fps: **14,789 frames**.
- Word-level alignment / word-for-word script match: NOT RUN; Codex must verify.
- Audio vendor: NOT VERIFIED; original filename refers to Onyx/GPT-4o-mini TTS; honor the uploaded audio for this test.
- One project-root AGENTS.md; unchanged compared with current master v2.1. The temporary testing exceptions are only in the episode brief and execution prompt.
- Existing screenshots and browser demo are source assets, **not an editing timeline**.
- Codex editor decisions and real Remotion full render: NOT RUN here.
- No quality promise until final MP4 is inspected.
