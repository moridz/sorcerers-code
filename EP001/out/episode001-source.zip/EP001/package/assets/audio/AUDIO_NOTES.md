# EP001 — uploaded narration audio

- **Source:** exact WAV the user uploaded in this conversation.
- **Canonical project file:** `assets/audio/narration_final.wav`.
- **Audio duration:** 492.950 seconds (8 min 12.95 sec); 24,000 Hz mono PCM 16-bit.
- **Uploaded filename:** `onyx_gpt-4o-mini-tts_1x_2026-11-02T04_49_11-337Z.wav`. The filename suggests Onyx / GPT-4o-mini TTS, **not Cartesia**. We cannot verify a vendor solely from a WAV or filename.
- **Rule:** Use this audio *as supplied* for the current test. Do not regenerate, replace, speed up, slow down or reconstruct the voiceover. Permanent Cartesia preference in the master is not modified.
- Audio codec/duration/headroom: checked. No clipping found in numeric sample scan. The first/last speech and word-for-word agreement with the source script have not yet been verified by transcript alignment.
- Re-align the 10 sections and all overlays against this exact WAV. Previously estimated 9:40 timings are invalid. Do not fabricate word-level timing.
- Music and sound effects OFF by default. No burned-in captions.

If the file does not match the intended script, flag the mismatch and request a narrow audio replacement before committing to full render.
