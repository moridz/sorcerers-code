# Codex Cloud — browser-only handoff

1. Create a **new private GitHub repository** at https://github.com/new (not the existing breakup-video repository).
2. Upload **the single `Codex_EP001_Editorial_Autonomy.zip` file** into the new repository via GitHub's browser upload control. The archive contains all assets, including the WAV. Keep it as a ZIP; **no local ChatGPT installation required**.
3. Open https://chatgpt.com/codex; choose **Work in > Cloud** and select/create an environment connected to that private repository. Codex will inspect the repository and help configure dependencies.
4. Start a task and paste the short task prompt given alongside this package. First ask Codex to extract the ZIP, read `AGENTS.md` and the episode brief. It should then work independently and produce `out/episode001-review.mp4`.
5. Review the actual video and QA report; only then decide what master-style changes deserve approval.

**Note:** Codex Cloud only sees files placed in its selected GitHub repository or cloud environment, not files attached in this chat. The final video has not yet been rendered.
