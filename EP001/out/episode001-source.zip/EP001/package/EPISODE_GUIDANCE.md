# MINIMAL FACELESS VIDEO — MASTER PRODUCTION WORKFLOW & CODEX INSTRUCTIONS

**Revision:** v2.1 (adds mandatory proven-video demand validation and reference-led original scripting before any topic can be selected)  
**Date:** 2026-11-02  
**Instruction scope:** Whole project / all episodes unless a specific user-approved episode exception applies  
**Status:** **OPERATING WORKFLOW ESTABLISHED; FULL VISUAL/AUDIO STYLE NOT YET LOCKED OR RENDER-VALIDATED.** Topic-selection proof gate is user-directed and mandatory. Never represent a proposed style preset as approved.  
**Approval:** User authorization + render/QA gate required before permanent style lock.

> **FOR CODEX:** This entire file is the project operating charter, editorial brief, template specification, audio policy, asset policy, and acceptance test. Follow it before building or editing any video. Read the entire file, inspect the actual project and provided assets, identify conflicts, and **do not improvise styles or replace approved inputs**. Use the installed Remotion skills to implement the rules for the project's actual version. This file defines behavior; it is not proof that code or rendering has run.

---

## 0. How one Markdown file instructs Codex

- **One master, many episode assets:** This file contains all production rules. Actual scripts/audio/video/episode manifests remain separate content files, not competing instruction masters.
- **Auto-load:** Copy/rename the file to **`AGENTS.md` at the Codex project root**; inspect any existing `AGENTS.md` and reconcile rather than overwriting it. Codex reads project `AGENTS.md` on session startup. Restart / start a fresh session, then ask it to report active instructions.
- **Keep original filename:** Alternatively tell Codex explicitly: `Read Minimal_Faceless_Video_Remotion_Workflow_v2.md and treat it as this project's master instructions.` Codex doesn't auto-discover this arbitrary filename by default.
- **Size:** Default Codex project-instruction budget is 32 KiB **combined** with other applicable instructions. Check aggregate size and avoid truncation; prefer this master at project root and no conflicting copies.
- **Use installed Remotion skills:** This guide governs editorial decisions; official skills govern API/version-compatible implementation. First inspect repo, package/lockfiles, Node, Remotion version and actual media; do not guess commands or claim installed dependencies.

## 1. Priority, evidence, approvals, and change control

**Order of authority:** (1) explicit current user instruction, (2) approved project/episode locks, (3) this master, (4) approved original source materials, (5) verified current documentation, (6) proposed defaults. Do not silently reinterpret an approved decision as an optional preference.

Use these status labels consistently:

- `LOCKED BY USER` — directly agreed editing principle or explicit production constraint; implement as written.
- `SELECTED REFERENCE` — user supplied a desired *direction*, not proof every color/easing/audio cue is authorized.
- `PROPOSED / AWAITING APPROVAL` — acceptable for a labeled prototype only; not a permanent project lock.
- `VERIFIED` — documentation, tested code, or observed artifacts support the specific claim; state exactly what was verified.
- `NOT VALIDATED` — absent supporting evidence, or not successfully executed; don't guess.
- `FAILED` — rejected result; don't turn it into a reusable master.

**No silent reversals:** Before changing an established position, record `CURRENT POSITION → NEW EVIDENCE → WHY INSUFFICIENT → PROPOSED CHANGE → DOWNSTREAM IMPACT → VERDICT (KEEP/REOPEN/REPLACE)`. A new video tutorial, interesting effect, or agent preference does **not** automatically override the workflow.

**Permanent-revision gate:** Compare with the last valid master; inspect conflicts and downstream impacts; run regressions, real Remotion render, frame/audio QA, and user review; only then lock. If that fails, retain last valid master and mark the revision failed.

## 2. Mission / what the viewer should receive

Create **useful, credible, attractive, minimal-effort long-form faceless YouTube videos** chosen only after verified exceptional YouTube demand, then informed by the selected successful reference video and original research. Design for the *buyer/viewer's understanding*, not editor-to-editor demonstrations, showcases, effects challenges, or decorative complexity. No reliance on YouTube revenue sharing as the production rationale.

**Single visual necessity test:** Every on-screen addition must do at least one job: **EXPLAIN**, **DEMONSTRATE**, or **PROVE**. If it does none, omit it. Storytelling can use genuine relevant footage where needed; do not force visuals at arbitrary time intervals.

**Production priorities:** accuracy and source integrity → intelligible natural narration → meaningful credible visuals → clear text → efficient repeatability → optional polish. Avoid unpaid manual work that doesn't improve the actual viewer experience.

**Hard prohibitions:** No unnecessary LUTs, random stock clips, automatic 3-second cut rules, constant kinetic typography, decorative transitions, fake product interfaces, invented results, lifeless cartoon talking heads, robotic placeholder voice in an accepted release, repeated illustrations used as filler, or sound effects added merely to impress editors. Do not manufacture authenticity or claim a synthetic visual is a real screen capture. Do not copy copyrighted reference footage, artwork, or proprietary template files into the output without rights.

## 3. Locked editing architecture — four logical tracks

```text
TOP     V3  B-ROLL / VISUAL INSERTS       [            ][insert] [           ]
        V2  TRANSPARENT TEXT / ELEMENTS   [label]         [key point]    [     ]
        V1  ONE CONTINUOUS A-ROLL + VOICE [===================================]
BOTTOM  A1  OPTIONAL BACKGROUND MUSIC    [...................................]
```

| Track | LOCKED BY USER: job | Rules |
| --- | --- | --- |
| `V1` | One continuous full-duration **A-roll master** with approved main narration | No visual gaps. This is **one assembled base video**, not necessarily one unchanged shot. May contain real action / screen demonstration / a deliberately preassembled *meaningful* visual reel. Slight reframing only where useful. |
| `V2` | Transparent text and essential contextual elements **above V1** | Key claims, titles, identifiers, checklists, progress, metrics where needed. Surroundings transparent; no generic opaque backgrounds. No permanent captions. |
| `V3` | Selective B-roll or visual proof **above V2** | Real demo, correct screenshot, actual document, photo/video with rights, or genuinely helpful explainer frame. Full-screen V3 temporarily hides V1 and V2. End when its job is complete. |
| `A1` | Optional background music **only** | Default **NONE** until approved. Never mask narration. No invented sound signature. |

**Narration implementation:** The approved Cartesia audio must remain one continuous, unduplicated main voice stream. Conceptually it belongs to V1. It may be muxed into `aroll.mp4` during preparation, or implemented as a synchronized `<Audio>` inside the V1 composition/group. It must **not** be duplicated while also playing from V1. A1 remains reserved for optional music. Mute incidental B-roll audio unless specifically approved as useful.

**Text + insert interaction:** V2 is directly above V1 and below V3. Do not time text behind an opaque V3 insert unless intentional; when V3 ends V1 automatically returns. No fake full-screen fills that obscure essential footage.

**Subtle zoom:** Start with candidate `scale=1.00–1.03`, slow smooth movement, never repetitive oscillation, never clip important UI or visual information. This is an *unvalidated starting preset*, not an empirically best rate. Restrained crop changes/punch-ins are allowed on meaningful footage. The base must be interesting even without zoom.

**Captions:** YouTube native captions/SRT only when requested; no burned-in full-sentence subtitles. Selective V2 emphasis text is distinct from captions.

## 4. Topic eligibility and A-roll visual strategy — decide before committing production

### MANDATORY PRE-SELECTION GATE: "Turn that Viral Videos Into the Next Winning Script"

**LOCKED BY USER:** `FIND TOP VIDEOS → VERIFY EXCEPTIONAL VIEWS + ENGAGEMENT + BUYER DEMAND → DECODE ONE WINNER → SELECT TOPIC → FACT RESEARCH → WRITE ORIGINAL SCRIPT`. A viable product, affiliate offer, article or visual idea **is not enough**. Until proof passes, status is `CANDIDATE — NOT SELECTED`.

1. **Find evidence:** Search public YouTube/web (never use the user's vidIQ account/credits) for the exact buyer problem and adjacent queries. Focus on relevant long-form videos, not unrelated viral Shorts. Log direct URLs, title, channel, publication date, length, observed views, likes/comments if visible, and check date.
2. **Prove unusual demand and interaction:** Compare with that channel's normal similar uploads, age of each video, and other competing creators. Inspect actual comments for active questions, purchase decisions, objections and follow-ups; prioritize repeatable outperformance and fresh activity. Views alone do not pass. Unavailable metrics are `UNKNOWN`; don't invent retention, CTR, conversions or sales. Seek independent corroborating videos.
3. **Pick and decode ONE winning video:** Inspect actual footage/transcript. Timestamp its hook and promise, target viewer, section sequence, pacing, visual cadence, evidence, objection handling and payoff. Explain **what is observed** versus **why it might work (inference)**. Do not substitute title or thumbnail analysis for viewing the video.
4. **Write the next winning script:** Use the reference's *proven editorial mechanisms* (hook type, structure, pacing, useful density), plus independently verified facts, original examples and the approved faceless format. **Do not copy its wording, distinctive expression, footage or shot sequence.** Performance inspiration is not content duplication.
5. **PASS/FAIL record:** Save `WINNER_DECODING.md` with lead/corroborating links, check dates, observed metrics, buyer-comment evidence, timestamped breakdown, faceless-asset suitability, limitations and a decisive verdict. **Only `PASS` permits `TOPIC SELECTED`.** If engagement or accessible lead-video evidence is insufficient, `NOT VALIDATED`; continue hunting, not scriptwriting.

**Separate roles:** This winning video defines *editorial performance inspiration*. User-selected Behance/Dribbble/Motion Array references in §6 define *visual style direction*. Neither authorizes copying assets.

A continuous **file** is not the same thing as a single static **image**. If no credible base footage can be made, the niche/video may not fit this efficient template. Don't cover a missing A-roll with arbitrary slides, stock, looped graphics, or a fake presenter.

| Content type | Candidate V1 foundation | Reality / rights gate |
| --- | --- | --- |
| Software/tools | Genuine screen-recorded product workflow, functioning UI | Record real actions; do not fabricate successful outcomes. |
| Business / product information | Authentic product footage, live page/UI, original comparisons, source-backed process | Confirm claims and clear rights; no invented app screenshots. |
| Cooking / physical topics | Actual food/activity footage or an assembled continuous reel of legally usable relevant shots | Cannot claim a cartoon or plate illustration is a true demonstration. |
| Data / explanation | Genuine documents, clear charts, tables, product evidence, approved visual explanation | Avoid abstract screensavers and unsupported numbers. |
| Story / abstract topics | Contextually meaningful scenes with coherent storytelling | Requires more visual creation; assess feasibility and effort honestly. |

**STOP GATE:** When suitable V1 visuals or legally usable evidence are missing, report exactly what is absent **before rendering**. Propose a viable source-based alternative or a more suitable topic; do not proceed by filling gaps with junk.

## 5. Research → article → script → Cartesia → Remotion → QA

**Source of truth:** An evidence-checked research brief or polished article. A blog post is **optional** unless the site also needs publication content; it must **not** be narrated verbatim by default. Reuse verified findings without plagiarizing others' text or artwork.

**Stage 0 — Proven-video research and topic selection:** Execute §4 viral-video discovery, metrics/interaction comparison, lead-video selection and timestamped hook/structure/pacing decoding **before** choosing a topic. Check buyer intent, suitable authentic V1 footage, source/rights feasibility and previous approved masters. **Gate:** evidenced `PASS` and `TOPIC SELECTED`; otherwise `CANDIDATE — NOT SELECTED` and continue topic hunting.

**Stage 1 — Independent factual research:** Use the Stage 0 winning-video analysis as an editorial reference, not a factual authority. Verify claims against original/authoritative sources, with URLs, limitations and contradictions. Optionally produce an article. **Gate:** independent factual ledger approved.

**Stage 2 — Winner-inspired ORIGINAL script/storyboard:** Decode the proven reference hook, sections and pacing (see §4) before drafting from independently approved research. Use original wording and examples; do not copy its expression or footage. Build a beat-level storyboard: spoken cue, viewer's question, planned shot/visual job (`EXPLAIN`, `DEMONSTRATE`, `PROVE`), V1/V2/V3 choice, evidence URL/asset, rights, and approximate timing. Do not make a new shot for every word. **Gate:** user-approved `SCRIPT` and `STORYBOARD`; do not rewrite them silently.

**Stage 3 — Cartesia:** Produce the approved final natural narration with Cartesia, preferably WAV. Record file metadata/actual duration. Request verified word timestamps or forced-align the approved script **to the actual final audio**. Verify selected cue phrases; no guessed alignment. Fix pronunciation/clipping before locking. **Gate:** voice, words, audio and timestamps approved.

**Stage 4 — Visual assets:** Obtain genuine screen recordings, relevant original or licensed HD footage, source documents, true screenshots and only necessary generated illustrations. Create an **asset dictionary**: `id, filename, action/subject, useful range, visual job, source URL, license, permitted use, approval`. Do not fake UI, results or source images; don't substitute repeated filler clips. **Gate:** relevant/cleared media or explicit gap report.

**Stage 5 — Continuous A-roll:** Build one uninterrupted V1 master: a genuine continuous demonstration or a cohesive *preassembled* reel of real relevant material. Embed/synchronize Cartesia exactly once (see §3). Check V1 in isolation, with voice, for complete duration, meaningful imagery and no black gaps. **Gate:** watchable V1-only preview.

**Stage 6 — Semantic beats:** Use verified word timing to decide *whether* a text/graphic/evidence insert genuinely helps at each moment. Do not use keyword triggers or an arbitrary change interval. Log `beat_id, cue/time, choice [V1 alone / V2 / V3], component or asset, why EXPLAIN/DEMONSTRATE/PROVE, rights/approval`. Align to speech; skip nonessential visuals. **Gate:** decision log reviewed, no invented visuals.

**Stage 7 — Agent + Remotion:** Codex inspects the actual repository, dependencies and Remotion API; invokes Remotion skills, and builds a **data-driven reusable** composition with full-length V1, transparent V2, timed V3 and optional A1. Derive frame timing from composition FPS and final audio. Reuse approved component presets rather than redesigning each episode. **Gate:** real Studio playback and inspected frames, not just written source code.

**Stage 8 — Approve/export:** Render a **30–60s representative Remotion test** and review actual motion, text, visuals and Cartesia sound. Fix evidence-backed defects without changing good sections; then full **540p review**, watched entirely with audio, then approved **1080p default final** (or episode-selected format). Verify exported MP4. **Gate:** technical PASS *and* human creative approval; a successful render alone is not approval.

## 6. Four user-selected style references (not fully locked)

Reference selection establishes *direction*, not exact reusable tokens or permission to copy assets.

| Ref | URL and role | Observed/known | Still UNKNOWN |
| --- | --- | --- | --- |
| **R1** | [Alqen AI explainer](https://www.behance.net/gallery/196701953/Animated-explainer-video-Alqen-AI) — optional full-screen concept/section frames | Near-black/deep violet, luminous purple/pink geometric motifs, large white type, structured SaaS storyboard and 2D frames. | Exact easing, shot timing, soundtrack. Not our global brand palette. |
| **R2** | [Conceptzilla CRM dashboard](https://dribbble.com/shots/27386635-CRM-Dashboard-Design-for-Sales-Performance-Management) — useful KPIs, comparison tables, information hierarchy | Readable KPI blocks, spacing, labels; published colors `#E6E8EA`, `#B9BBC2`, `#5A5B5F`, `#0E0E10`, `#E3D4AD`, `#BD6C3A`. | Its motion, any approval to adopt colors as global identity. No fake live product UI. |
| **R3** | [Step Progress Bars / Bullet Checklist](https://motionarray.com/after-effects-templates/step-progress-bars-bullet-checklist-1280270/) — actual steps/checks/progress | Vendor lists four editable After Effects checklist/progress variants. | Exact motion/easing. **No direct Remotion compatibility or free source license**; write original behavior. |
| **R4** | [Titles and Lower Thirds](https://motionarray.com/after-effects-templates/titles-and-lower-thirds-3393158/) — essential titles, labels, lower-thirds | User selected this particular overlay category. | Exact preview/fonts/palette/motion **not retrieved/verified**; don't invent details. |

**Conflict:** R1 dark/violet promotional treatment and R2 neutral/light data UI are **not one coherent brand palette**. *Proposed test separation:* R1 only for useful concept frames, R2 for data panels, R3 for actual procedures, R4 for transparent labels over V1. Not yet user-approved. Readability and factual accuracy override decoration.

**Provisional defaults, not permanent locks:** 16:9 for long-form, legible text with safe margins and adequate contrast, subdued entry/exit when needed. Typeface, exact typography scale, colors, easing and motion timing remain unapproved until tested. Avoid full-screen title cards or other visuals with no explanatory job.

## 7. Reusable Remotion component library (to build/test once)

These **component types** are selected for development; their *exact look, typography, easing, dimensions, audio cues and timing* remain `PROPOSED / AWAITING APPROVAL`.

| Component key | Track | Apply only when |
| --- | --- | --- |
| `Text_Transparent_01` | V2 | One important phrase/figure needs emphasis. |
| `LowerThird_01` | V2 | Source, speaker, product, person or place needs a short identifier. |
| `Checklist_01` | V2 (or V3 if genuinely full-screen) | Real sequence/requirements are spoken; reveal items at verified cues. |
| `Progress_01` | V2 | A real measurable process stage exists. No fake percentages. |
| `KPI_Card_01` | V2/V3 | Verified quantitative results must be compared. |
| `Evidence_Panel_01` | V3 | Actual screenshot/document/table is legible and supports the spoken claim. |
| `Explainer_Frame_01` | V3 | A concept is genuinely clearer visually; original graphics, no filler. |
| `Broll_Insert_01` | V3 | Accurate footage shows a demonstration/example/evidence and has usable rights. |

**Component approval procedure:** (a) inspect reference preview or supplied screenshot, (b) describe exact desired position, spacing, typography, palette, entering/exiting behavior and duration, (c) build and render a real representative scene, (d) review with narration and actual V1 footage, (e) save approved component source + version + example frame + user decision. Until then, do not claim that reference timing or animation has been recreated exactly.

**No special effects by default:** No automatic paper textures, luminous flares, glassmorphism, LUTs, 3D logos, rotoscoping, click/woosh per overlay, or title stings merely because a tutorial showcases them. An exception requires a specified informative reason and user approval.

## 8. Audio master — Cartesia is fixed; music/SFX are not

- **Narration provider:** Cartesia. Use the user's final approved voice performance/audio. Preserve original prosody, word order and timing. **Do not generate an alternative voice** or re-time it without approval.
- **Narration quality:** Check natural pronunciation, loudness consistency, breath spacing, absent distortion, and integration with visuals. No robotic placeholders for a release.
- **Music preset:** **NONE** is the operative default. No specific background track, music mood, tempo, stock provider, loop or license has been approved. Do not invent a sonic brand from still image references.
- **SFX preset:** **NONE** is the operative default. Optional clicks, transitions or impacts require proven usefulness and a user-approved sound file/preset.
- **When music is approved later:** Record track filename/hash, usage rights, entry/exit rules, exact listening-tested mix level, ducking behavior, and approved example scene. Prioritize spoken intelligibility; never replace listening with a generic numeric volume rule.
- **Audio identification:** Store clip hashes/IDs and rights. Do not use music from a sample video without explicit rights.
- **SRT/native subtitles:** Keep as separate optional output, not burned into V2.

## 9. Episode artifact manifest and timing contract

The **master stays one Markdown file**. Episode outputs may be many working files (they are content, not new master rulebooks):

```text
episodes/EP001/
  WINNER_DECODING.md          # validated video links, metrics, engagement, hooks, pacing
  RESEARCH.md                 # independent factual sources, claim ledger, limitations
  ARTICLE.md                  # optional source article / site publication
  SCRIPT_APPROVED.md          # exactly narrated words
  STORYBOARD.json             # approved meaning beats / shot jobs
  voiceover.wav               # final Cartesia audio
  word_timestamps.json        # from final audio; with provenance
  assets/                     # licensed/original real footage/images
  asset_manifest.json         # descriptive asset dictionary + rights
  timeline.json               # decisions: V1 V2 V3 A1
  output/                     # review and final MP4, QA results
```

**Example only — schema to implement and validate in code, not a tested parser:**

```json
{
  "episodeId": "EP001",
  "source": {"article": "ARTICLE.md", "script": "SCRIPT_APPROVED.md"},
  "audio": {"file": "voiceover.wav", "timestamps": "word_timestamps.json", "approved": true},
  "v1": {"file": "aroll.mp4", "continuous": true, "zoom": {"enabled": true, "range": [1.0, 1.03]}},
  "v2": [{"startSec": 17.2, "endSec": 20.1, "component": "Text_Transparent_01", "text": "Actual key term", "beatId": "beat-04"}],
  "v3": [{"startSec": 32.8, "endSec": 37.5, "assetId": "approved-demo-01", "mute": true, "beatId": "beat-07"}],
  "a1": null,
  "video": {"width": 1920, "height": 1080, "fps": 30}
}
```

**Timing rules:** timestamps are based on actual final narration. Verify transcription accuracy, cut alignment and source media duration; clamp/flag out-of-range events; no overlaps that hide required information; retain deterministic output. Beat map must preserve source citations and asset IDs. Example numbers above are illustrative, not a validated episode or approved frequency.

## 10. Codex responsibilities and execution contract

**MAY:** inspect approved research, real footage and local files; verify evidence/rights; catalog assets; suggest minimal text/B-roll; create actual working screen recordings; implement approved components; align final Cartesia audio; build Remotion code; render/test; identify defects; make scoped corrections.

**MUST NOT:** rewrite approved script/storyboard/voice, invent claims/results or fake UI, lift proprietary reference assets, replace real footage with lifeless cartoons, force random stock/visual frequency, introduce unapproved styles/audio, alter unrelated repositories, replace locked masters, or report code/FFmpeg previews as a successful Remotion render.

**Procedure:** `VIRAL VIDEO SEARCH → DEMAND/INTERACTION PROOF → WINNER DECODING → TOPIC PASS → INDEPENDENT RESEARCH → ORIGINAL SCRIPT → ASSET GAP CHECK → V1 → SEMANTIC BEATS → APPROVED COMPONENTS → REAL REMOTION SAMPLE → INSPECT → SCOPED FIXES → 540p REVIEW → FULL WATCH → FINAL RENDER → REPORT`.

For localized corrections, preserve approved audio, timing and valid scenes; verify no regression. Codex + ChatCut/HyperFrames tutorial demos show useful patterns with authentic supplied footage, **not validation of this particular pipeline**. At task start report available inputs, missing inputs, governing locks and requested deliverable. Never promise work later or invent success. Don't render unless authorized.

## 11. QA gates — do not confuse technical success with viewer quality

### Technical checks — automatic/inspection
- [ ] Actual Remotion command/studio operation completed; state command and real output path.
- [ ] Verify file exists and decodes; correct duration, resolution, FPS, codecs and **one** main narration stream.
- [ ] No missing audio, accidental blank frames, frozen filler, duplicated footage, uncontrolled footage source sound, premature truncation or frame cropping.
- [ ] Every V2/V3 event corresponds to correct audible words; no text hides behind full-screen inserts accidentally.
- [ ] Text remains legible at real intended viewing size; no collisions / unsafe margins / misleading figures.
- [ ] License/source records exist for every third-party asset. Real screenshots show real app state, not invented UI.
- [ ] Frame contact sheet sampled across every insert/change and actual full audio preview inspected.

### Human creative acceptance — mandatory before calling an output high quality
- [ ] The first 20–30 seconds show the promised outcome without filler.
- [ ] Watch the **entire video at normal speed with sound**; voice sounds natural, visuals match claims, no visual boredom caused by repeated empty A-roll.
- [ ] Transparent text actually helps; delete unnecessary overlays.
- [ ] B-roll footage is relevant/credible and not being looped as decorative filling.
- [ ] The overall style resembles the **approved** reference behavior; don't confuse a similar color with an exact style reproduction.
- [ ] If the user rejects quality, mark `FAILED QUALITY`, retain the last valid project, identify the causes and repair only verified defects.

**Acceptance levels:** `CODE WRITTEN` ≠ `PREVIEW RUNNING` ≠ `REMOTION RENDER VERIFIED` ≠ `CREATIVE QUALITY APPROVED` ≠ `AUDIENCE PERFORMANCE PROVEN`. Never conflate these.

## 12. Exact visual/audio style-lock protocol — PENDING

1. Obtain usable R3/R4 video/screenshot references and **observe** their real movement; distinguish observation from inference.
2. Select typography hierarchy, safe margins, accessible contrast, approved palette, easing, element positions and timing; reconcile dark R1 and neutral R2 roles. Do not infer master colors from reference artwork.
3. Approve specific music and SFX audio **or permanently choose no music/SFX**. Until then both are off.
4. Make an **actual Remotion** 30–60s style pilot with approved Cartesia voice, real V1 and genuinely appropriate V2/V3 components; use a separate component-demo only where needed.
5. Review rendered motion, sound, cropping, narration sync, source integrity and similarity to the selected references. Correct only verified defects.
6. Record approved component source/version, style tokens, audio hashes/rights and user decision; compare last valid master and run regression checks. Only then declare `FINAL LOCKED vX.Y`.

**The four-track architecture is locked; typography, exact visuals, transitions and audio identity are not.** A written document doesn't create assets or prove the Remotion render works.

## 13. Lessons from rejected tests (do not resurrect)

User reports an earlier grocery-list webpage produced a ~1-minute video with little instruction: that is evidence for that particular successful page-to-video run, not proof of consistently good long-form video. Subsequent 55–58s tests assembled with **FFmpeg** showed layers but not Remotion, and used poor placeholder visuals/robotic speech. The 85s breakfast presenter and 55s keyword beat selector **FAILED creative quality**: static cartoon, invented/repetitive imagery, weak text, non-semantic timing. These are not approved templates. External Codex/ChatCut/HyperFrames demonstrations use **real supplied footage**, proving useful agent editing patterns but not an autonomous long-form faceless A-roll pipeline in this repo.

## 14. Ready-to-use Codex launch prompt

> Read this project's `AGENTS.md` fully. Do not select a topic until §4 public YouTube performance/interaction evidence and timestamped winner decoding PASS. Inspect the actual approved episode inputs and repository. Use Remotion skills and the locked four-track design; preserve Cartesia voice, script, storyboard and approved style. Build and **render in Remotion** a 30–60s representative pilot from real approved visuals. Inspect audio/timing/frames and report PASS/FAIL with the real output path; never substitute FFmpeg, stock filler, invented effects, or unapproved sound. Keep valid work unchanged while fixing defects.

Only render when explicitly authorized by the current user request. Otherwise review or plan as requested.

## 15. Reference and implementation links

**User-selected reference board** (selection acknowledged, exact motion/audio not yet fully verified): R1–R4 in §6.  
**Original reference video:** user-provided ~21-minute talking-head sample; informs A-roll + text + B-roll *architecture*, not audio (supplied version had no audio stream).  
**Remotion:** [AI skills](https://www.remotion.dev/docs/ai/skills), [compositions](https://www.remotion.dev/docs/composition), [video/audio](https://www.remotion.dev/docs/video-and-audio), [render](https://www.remotion.dev/docs/render).  
**Codex:** [AGENTS.md instructions](https://learn.chatgpt.com/docs/agent-configuration/agents-md).  
**Source/rights:** [Pexels license](https://www.pexels.com/license/), [YouTube Analytics audience retention](https://support.google.com/youtube/answer/9314415).  
**Editorial rationale:** [Adobe A-roll](https://www.adobe.com/creativecloud/video/discover/a-roll.html), [Adobe B-roll](https://www.adobe.com/au/creativecloud/video/discover/b-roll.html).

---

### Current authority ledger (read this before declaring anything locked)

**LOCKED BY USER:** validated exceptional YouTube video demand/interactions BEFORE topic selection; decode one proven winner's hook, structure and pacing into an independently researched ORIGINAL script; continuous V1 main A-roll and approved narration; optional modest reframing; selective transparent V2; selective purpose-driven V3; A1 optional music; no unnecessary editing; Cartesia for final narration; faceless, credible useful visual presentation; no compulsory burned-in captions.  
**SELECTED REFERENCE:** Alqen overall concept frames; CRM information hierarchy; checklist/progress; title/lower-third gallery example.  
**PROPOSED / NOT LOCKED:** exact typography, global brand color palette, precise easing/durations, animation library visuals, reference reproduction, precise zoom schedule, music track, SFX library, final playback/mix numbers and default output format beyond episode needs.  
**TESTED BUT NOT ACCEPTED:** prior FFmpeg experiments and rejected illustrated presenter output.  
**NOT YET VERIFIED IN THIS MASTER:** full agent-driven Remotion rendering with approved real assets, final narration, and actual creative quality acceptance.
