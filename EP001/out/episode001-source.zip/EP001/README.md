# EP001 — From a Messy Sales Spreadsheet to a Clear Pipeline

An isolated Remotion production using the supplied fictional Pipeline Lab application
and the unmodified final 492.95-second narration. KevinCookieCompany and the root
production configuration are not changed.

## Preview and reproduce

Requires Node 22+ and Chromium. From this directory:

```sh
npm ci
python3 tools/build-demo.py
npm start -- --no-open
```

Select EP001 in Studio (port 3001). `src/timeline.json` contains the shot states;
`src/chapters.json` contains the actual audio-aligned chapter starts. The app's
original data/rendering logic lives unchanged in `package/demo/index.html`.
`public/demo.html` adds only deterministic replay, editorial focus outlines, and a
cursor. This is an instrumented original fictional demo, not a commercial CRM
capture or a claim that manual screen activity was filmed in real time.

Render the base presentation, then the final episode:

```sh
npx remotion render src/index.ts V1-Master public/aroll.mp4 --browser-executable=/usr/bin/chromium --concurrency=4 --codec=h264 --crf=18
npm run render
```

On other operating systems omit `--browser-executable=/usr/bin/chromium` or point
it to a supported local Chromium installation. If necessary edit that path in the
render script. Never change narration playback rate to fit a video.

`package/` preserves all supplied source material. The ZIP's AGENTS.md is stored as
`package/EPISODE_GUIDANCE.md`, deliberately not installed as a root instruction.
No permanent production rules or environment settings are modified.

## Architecture and editorial rationale

- **V1:** One uninterrupted 1920×1080 app presentation assembled with Remotion:
  actual provided UI states, genuine move/filter behavior, purposeful scrolling,
  cursor guidance, and selective readable crops. All numbers remain source data.
- **Narration:** One continuous Audio instance starting at frame 0. Supplied WAV
  is byte-identical; no time stretching, replacement voice, EQ, music, or SFX.
- **V2:** Transparent chapter identifiers and sparse rule emphasis outside the UI.
  No full-sentence burned-in captions.
- **V3:** Original source-based definition, comparison, and weekly-routine panels.
  Limitations are disclosed rather than fabricating missing app features.
- **A1:** Empty. No music or sound effects were supplied/approved.

`out/qa/QA_REPORT.md` records actual checks, limits, and render evidence. A rendered
review is not a new permanent style lock or human creative approval.

The production run uses the equivalent Remotion Renderer API pipeline:

```sh
npm run render:cached
.venv/bin/python tools/qa-final.py
.venv/bin/python tools/qa-visual.py
```

The cache renders **all changing native 30 fps frames**, retains each exact static
hold via identical image bytes, and invokes Remotion `stitchFramesToVideo` for
encoding. It does not reduce the animation frame rate, trim speech, or loop clips.
The conventional commands above remain available for a full per-frame rerender.

Speech alignment/QA dependencies (optional for replaying the finished edit):

```sh
python3 -m venv .venv
.venv/bin/pip install pocketsphinx==5.0.4 pillow
.venv/bin/python tools/align.py
.venv/bin/python tools/transcribe.py
.venv/bin/python tools/cues.py
.venv/bin/python tools/audio-check.py
```

For a simple local player after rendering:

```sh
python3 -m http.server 3002 --directory out
```

In Codespaces, open port 3002 from its **Ports** tab. The `out/index.html` player
provides the full video and QA/source downloads. Cloud-workspace localhost URLs
are not links to a separate Codespace.

Final narration encoding uses the source WAV **directly as mono** via Remotion's
supported `ffmpegOverride` finishing interface. This avoids a measured 3 dB
mono-to-stereo conversion in the default mix. The picture is still rendered and
assembled entirely with Remotion; no replacement narration or retiming occurs.
`npm run render` includes the same audio finishing step. The original default-mix
review and pre-framing-correction video are retained locally as QA backups.
